﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using igadgets.Models;
using igadgets;
using System.Collections.ObjectModel;

namespace igadgets
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class AddingWindow : Window
    {
        private string imgPath = @"D:\BSTU\4 sem\ООП\Лабы\4-7\testik4-5\img\ez.jpg";
        public AddingWindow()
        {
            InitializeComponent();

        }

        public void NewElementCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            uint maxId = 0;

            var Product = new Products();
            var list = MainWindow.Products.GetProducts();
            if (list != null)
                foreach (var t in list)
                {
                    if (t.Id > maxId)
                    {
                        maxId = t.Id;
                    }
                }
            try
            {
                Product.Id = maxId + 1;

                Product.Title = TitleFiled.Text;
                Product.ImagePath = imgPath + ImageFiled.Text;
                Product.Company = CompanyFiled.Text;
                Product.Price = decimal.Parse(PriceFiled.Text);
                Product.Description = DescriptFiled.Text;
                Product.Rating = (float)RateFiled.Value;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            MainWindow.Products.AddItem(Product);

            MainWindow.story.Add(new ObservableCollection<Products>(MainWindow.Products.GetProducts()));
            MainWindow.count++;

            this.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
