﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.IO;

using Newtonsoft.Json;


namespace igadgets.Models
{
    public class ProductsRepository
    {
        private readonly string pathData = @"D:\BSTU\4 sem\ООП\Лабы\4-7\testik4-5\Services\Products.json";
        private readonly string pathFilter = @"D:\BSTU\4 sem\ООП\Лабы\4-7\testik4-5\Services\Filter.json";

        private ObservableCollection<Products> ProductsList = new ObservableCollection<Products>();
        private ObservableCollection<string> FilterList = new ObservableCollection<string>();



        public ProductsRepository()
        {
            ProductsList = new ObservableCollection<Products>();
        }
        public ObservableCollection<Products> GetProducts()
        {
            return ProductsList;
        }
        public Products GetItemById(uint id)
        {
            return ProductsList.Where(ProductsList => ProductsList.Id == id).FirstOrDefault();
        }
        public ObservableCollection<string> GetFilter()
        {
            return FilterList;
        }
        public void AddItem(Products item)
        {
            bool Flag = false;
            ProductsList.Add(item);
            foreach (var item2 in FilterList)
            {
                if (item.Company == item2)
                {
                    Flag = true;
                    break;
                }
            }
            if (Flag != true)
            {
                FilterList.Add(item.Company);
            }

            CommitData();
        }
        public void LocalCommit()
        {
            Products[] tmpl = new Products[ProductsList.Count()];
            ProductsList.CopyTo(tmpl, 0);
            ProductsList.Clear();
            FilterList.Clear();
            for (int i = 0; i < tmpl.Length; i++)
            {
                bool Flag = false;

                ProductsList.Add(tmpl[i]);
                foreach (var item2 in FilterList)
                {
                    if (tmpl[i].Company == item2)
                    {
                        Flag = true;
                        break;
                    }
                }
                if (Flag != true)
                {
                    FilterList.Add(tmpl[i].Company);
                }
            }

            CommitData();
        }
        public void CommitData()
        {
            using (StreamWriter writer = File.CreateText(pathData))
            {
                string output = JsonConvert.SerializeObject(ProductsList);
                writer.Write(output);
            }
            using (StreamWriter writer = File.CreateText(pathFilter))
            {
                string output = JsonConvert.SerializeObject(FilterList);
                writer.Write(output);
            }
        }

        public void OutputData()
        {
            var FileExists = File.Exists(pathData);
            if (!FileExists)
            {
                File.CreateText(pathData).Dispose();
            }
            else
            {
                using (var reader = File.OpenText(pathData))
                {
                    var FileText = reader.ReadToEnd();
                    ProductsList = JsonConvert.DeserializeObject<ObservableCollection<Products>>(FileText);
                }
            }
        }
        public void OutputFilter()
        {
            var FileExists = File.Exists(pathFilter);
            if (!FileExists)
            {
                File.CreateText(pathFilter).Dispose();
            }
            else
            {
                using (var reader = File.OpenText(pathFilter))
                {
                    var FileText = reader.ReadToEnd();

                    FilterList = JsonConvert.DeserializeObject<ObservableCollection<string>>(FileText);
                }
            }

        }

        public void DeleteProduct(uint id)
        {
            foreach (var item in ProductsList)
            {
                if (item.Id == id)
                {
                    ProductsList.Remove(item);
                    break;
                }
            }
            LocalCommit();
        }
    }
}
