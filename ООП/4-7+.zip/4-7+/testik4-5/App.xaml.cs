﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows;

namespace igadgets
{
    public partial class App : Application
    {
        
    }
}