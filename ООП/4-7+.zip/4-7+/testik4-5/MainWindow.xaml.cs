﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using igadgets.Models;
using System.Globalization;
using System.Windows.Resources;


namespace igadgets
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static int count { get; set; } = 0;
        public static ProductsRepository Products { get; set; } = new ProductsRepository();
        private ObservableCollection<Products> filter = new ObservableCollection<Products>();
        private ObservableCollection<Products> deleted = new ObservableCollection<Products>();
        public static List<ObservableCollection<Products>> story { get; set; } = new List<ObservableCollection<Products>>();

        public List<string> Langs = new List<string>() { "ru-RU", "en-US" };
        public MainWindow()
        {
            InitializeComponent();

            Products.OutputData();
            Products.OutputFilter();
            productList.ItemsSource = Products.GetProducts();
            Filter.ItemsSource = Products.GetFilter();
            story.Add(new ObservableCollection<Products>(Products.GetProducts()));
            InitLangsBox();

            List<string> styles = new List<string> { "Light", "Dark" };
            StyleBox.SelectionChanged += ThemeChange;
            StyleBox.ItemsSource = styles;
            StyleBox.SelectedItem = "Dark";
        }

        // 7 лаба 
        // определение событие
        public static readonly RoutedEvent ClickEvent;

        static MainWindow()
        {
            // регистрация маршрутизированного события
            MainWindow.ClickEvent = EventManager.RegisterRoutedEvent("Click",
                RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(MainWindow));
            //................................
        }
        // обертка над событием
        public event RoutedEventHandler Click
        {
            add
            {
                // добавление обработчика
                base.AddHandler(MainWindow.ClickEvent, value);
            }
            remove
            {
                // удаление обработчика
                base.RemoveHandler(MainWindow.ClickEvent, value);
            }
        }

        private void ThemeChange(object sender, SelectionChangedEventArgs e)
        {
            string style = StyleBox.SelectedItem as string;
            // определяем путь к файлу ресурсов
            var uri = new Uri("Resources/" + style + "Theme" + ".xaml", UriKind.Relative);
            // загружаем словарь ресурсов
            ResourceDictionary resourceDict = Application.LoadComponent(uri) as ResourceDictionary;
            // очищаем коллекцию ресурсов приложения
            Application.Current.Resources.Clear();
            // добавляем загруженный словарь ресурсов
            Application.Current.Resources.MergedDictionaries.Add(resourceDict);
        }
        private void InitLangsBox()
        {
            LanguageComboBox.ItemsSource = Langs;
        }
        private void SetCursor()
        {

            Cursor customCursor = new Cursor("D:\\BSTU\\4 sem\\ООП\\Лабы\\4-7\\testik4-5\\img\\pointer.cur");
            this.Cursor = customCursor;
        }
        private void CreateButton_Click(object sender, RoutedEventArgs e)
        {

            var newWindow = new AddingWindow();
            newWindow.Owner = this;
            newWindow.Show();
        }
        private void MainWindow_Loaded(object sender, EventArgs e)
        {
            SetCursor();
        }
        private void Filter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            filter = new ObservableCollection<Products>();
            foreach (var item in Products.GetProducts())
            {
                var sneak = Filter.SelectedItem.ToString();
                if (sneak == item.Company)
                {
                    filter.Add(item);
                }

            }

            productList.ItemsSource = filter;
        }



        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Text_From.Text = "";
            Text_To.Text = "";
            productList.ItemsSource = Products.GetProducts();
        }

        private void Change_button_click(object sender, RoutedEventArgs e)
        {
            try
            {
                var selectedItem = (Products)productList.SelectedItem;
                var newWindow = new ChangeWindow(selectedItem.Id);
                newWindow.Owner = this;
                newWindow.Show();
            }
            catch (Exception er)
            {
                MessageBox.Show("Выберите элемент, который хотите изменить.");
            }
        }

        private void Delete_button_click(object sender, RoutedEventArgs e)
        {
            try
            {
                var selectedItem = (Products)productList.SelectedItem;
                Products.DeleteProduct(selectedItem.Id);
                deleted.Add(selectedItem);

                story.Add(new ObservableCollection<Products>(Products.GetProducts()));
                count++;
            }
            catch (Exception er)
            {
                MessageBox.Show("Выберите элемент, который хотите удалить.");

            }

        }

        private void Search_button_click(object sender, RoutedEventArgs e)
        {
            string searchString = SearchField.Text;
            Regex regex = new Regex(searchString, RegexOptions.IgnoreCase);
            var filter = new List<Products>();
            foreach (var phone in Products.GetProducts())
            {
                if (regex.IsMatch(phone.Title)|| regex.IsMatch(phone.Company))
                    filter.Add(phone);
            }
            productList.ItemsSource = filter;

        }
        public void PriceFilter()
        {
            var list = new List<Products>();
            decimal from, to;
            try
            {
                if (Text_To.Text == "" && Text_From.Text == "")
                {
                    productList.ItemsSource = Products.GetProducts();

                }
                else
                {
                    foreach (var item in Products.GetProducts())
                    {

                        if (Text_To.Text == "")
                        {
                            to = Decimal.MaxValue;
                            if (item.Price >= Convert.ToDecimal(Text_From.Text) && item.Price <= Convert.ToDecimal(to))
                            {
                                list.Add(item);
                            }
                        }
                        else if (Text_From.Text == "")
                        {
                            from = -1;
                            if (item.Price >= Convert.ToDecimal(from) && item.Price <= Convert.ToDecimal(Text_To.Text))
                            {
                                list.Add(item);
                            }
                        }

                        else if (item.Price >= Convert.ToDecimal(Text_From.Text) && item.Price <= Convert.ToDecimal(Text_To.Text))
                        {
                            list.Add(item);
                        }

                    }
                    productList.ItemsSource = list;

                }
            }
            catch (Exception er)
            {

            }

        }
        private void Block_from_changed(object sender, TextChangedEventArgs e)
        {
            PriceFilter();
        }

        private void Block_to_changed(object sender, TextChangedEventArgs e)
        {
            PriceFilter();
        }
        private void LanguageComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SetLanguageDictionary(this, LanguageComboBox.SelectedItem.ToString());
        }

        public void UndoCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            productList.ItemsSource = story[--count];
            
            if (deleted.Count>0)
            Products.AddItem(deleted[0]);
        }

        private void RedoCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            productList.ItemsSource = story[++count];

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }

        //7 лаба

        private void Control_MouseDown(object sender, MouseButtonEventArgs e)
        {
            //textBlock1.Text = string.Empty;
            textBlock1.Text = textBlock1.Text + "sender: " + sender.ToString() + "\n";
            textBlock1.Text = textBlock1.Text + "source: " + e.Source.ToString() + "\n\n";
        }

        private void button4_Click(object sender, RoutedEventArgs e)
        {
            textBlock1.Text = string.Empty;

        }

        private void Control_MouseEnter(object sender, MouseEventArgs e)
        {
            textBlock1.Text = string.Empty;

            textBlock1.Text = textBlock1.Text + "sender: " + sender.ToString() + "\n";
            textBlock1.Text = textBlock1.Text + "source: " + e.Source.ToString() + "\n\n";
        }

        private void Exit_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            using (System.IO.StreamWriter writer = new System.IO.StreamWriter("log.txt", true))
            {
                writer.WriteLine("Выход из приложения: " + DateTime.Now.ToShortDateString() + " " +
                DateTime.Now.ToLongTimeString());
                writer.Flush();
            }

            this.Close();
        }
        private void RoutedUICommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (unvisibleTxtB.Visibility == Visibility.Visible)
            {
                unvisibleTxtB.Visibility = Visibility.Hidden;
            }
            else
            {
                unvisibleTxtB.Visibility = Visibility.Visible;
            }
        }
        private static ResourceDictionary GetResourceDictionary(string cultureTitle)
        {
            ResourceDictionary dict = new ResourceDictionary();
            switch (cultureTitle)
            {
                case "en-US":
                    dict.Source = new Uri($"Resources\\Lang.{cultureTitle}.xaml", UriKind.Relative);
                    break;
                default:
                    dict.Source = new Uri($"Resources\\Lang.ru-RU.xaml", UriKind.Relative);
                    break;
            }
            return dict;
        }
        private static void setResourceDictionary(Window window, ResourceDictionary dict)
        {
            var dictionariesToDelete = new List<ResourceDictionary>();
            foreach (var dictionary in window.Resources.MergedDictionaries)
                if (new Regex("Lang.*?.xaml").IsMatch(dictionary.Source.ToString()))
                    dictionariesToDelete.Add(dictionary);

            foreach (var dictionary in dictionariesToDelete)
                window.Resources.MergedDictionaries.Remove(dictionary);

            window.Resources.MergedDictionaries.Add(dict);
        }
        public static void SetLanguageDictionary(Window window, string cultureTitle)
        {
            var dict = GetResourceDictionary(cultureTitle);

            setResourceDictionary(window, dict);
            foreach (Window childWindow in window.OwnedWindows)
            {
                setResourceDictionary(childWindow, dict);
            }
        }
    }
}
