﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using igadgets.Models;
using igadgets;
using System.Collections.ObjectModel;

namespace igadgets
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class ChangeWindow : Window
    {
        public uint SneakId { get; set; }
        public ChangeWindow(uint Id) : this()
        {
            InitializeComponent();
            SneakId = Id;
            InitForm();
        }

        public ChangeWindow()
        {
        }

        private void InitForm()
        {
            Products Sneak = MainWindow.Products.GetItemById(SneakId);
            TitleFiled.Text = Sneak.Title;
            CompanyFiled.Text = Sneak.Company;
            DescriptFiled.Text = Sneak.Description;
            ImageFiled.Text = Sneak.ImagePath;
            PriceFiled.Text = Sneak.Price.ToString();
            RateFiled.Value = Sneak.Rating;
        }
        public void ChangeElementCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            var canNullablePhone = MainWindow.Products.GetItemById(SneakId);
            if (canNullablePhone == null) return;

            var Sneak = canNullablePhone;
            Sneak.Title = TitleFiled.Text;
            Sneak.Company = CompanyFiled.Text;
            Sneak.Description = DescriptFiled.Text;
            Sneak.ImagePath = ImageFiled.Text;
            Sneak.Price = decimal.Parse(PriceFiled.Text);
            Sneak.Rating = (float)RateFiled.Value;


            MainWindow.Products.LocalCommit();
            MainWindow.Products.CommitData();
            MainWindow.story.Add(new ObservableCollection<Products>(MainWindow.Products.GetProducts()));
            MainWindow.count++;
            this.Close();
        }

    }
}
