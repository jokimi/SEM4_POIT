#include <afxwin.h>
#include <afxdlgs.h>
#include "CMainWnd.h"
#include "CMyApp.h"

CMyApp theApp;